#ifndef _PRINT_INFO_H_
#define _PRINT_INFO_H_

extern void login_info(char* usrname, char* pssword);
extern int choose_func();


#endif // PRINT_INFO_H_
