#include <stdio.h>
#include "print_info.h"

char usrname[16], pssword[16];
void arm_sys(){}
void disarm_sys(){}
void monitor_room(){}
void report_errs(){}
void modify_sys(){}
void exit_sys(){}

int main()
{
    int choose_id;
    login_info(usrname,pssword);
    choose_id = choose_func();
    switch(choose_id)
    {
    case 1:     //��װϵͳ
        arm_sys();
        break;
    case 2:     //���ϵͳ
        disarm_sys();
        break;
    case 3:      //����ͷ
        monitor_room();
        break;
    case 4:     //�������
        report_errs();
        break;
    case 5:     //�������ô�������ϵͳ
        modify_sys();
        break;
    case 6:     //�˳�ϵͳ
        exit_sys();
        break;
    }
    return 0;
}
