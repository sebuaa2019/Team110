#ifndef _PRINT_INFO_H_
#define _PRINT_INFO_H_
#include <stdio.h>

extern void login_info(char* pssword);
extern int choose_func();


#endif // PRINT_INFO_H_
